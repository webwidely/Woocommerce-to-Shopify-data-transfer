<?php
/**
 * Plugin Name: WooCommerce -> Shopify Exporter (Webwidely)
 * Description: Export WooCommerce products & customers in Shopify-compatible CSV format and optionally push data to a Shopify store via Admin API.
 * Version: 0.1
 * Author: Webwidely / Abdul
 * Text Domain: wws-shopify-exporter
 */

if (!defined('ABSPATH')) {
    exit;
}

// Basic dependency check
add_action('admin_init', function() {
    if (is_admin() && current_user_can('activate_plugins') && !class_exists('WooCommerce')) {
        add_action('admin_notices', function() {
            echo '<div class="notice notice-error"><p><strong>WooCommerce &rarr; Shopify Exporter</strong> requires WooCommerce to be active.</p></div>';
        });
    }
});

// Load required files
require_once plugin_dir_path(__FILE__) . 'includes/class-wws-utils.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-wws-exporter.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-wws-shopify-api.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin/class-wws-admin-pages.php';
require_once plugin_dir_path(__FILE__) . 'includes/admin/class-wws-admin-handlers.php';
require_once plugin_dir_path(__FILE__) . 'includes/class-wws-admin.php';

// Initialize the plugin
WWS_Shopify_Exporter::instance();

// Register settings
add_action('admin_init', function() {
    register_setting('wws_shopify_settings', 'wws_shopify_store');
    register_setting('wws_shopify_settings', 'wws_shopify_token');
    register_setting('wws_shopify_settings', 'wws_shopify_default_vendor');
});
?>