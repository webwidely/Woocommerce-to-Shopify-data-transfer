jQuery(document).ready(function($) {
    var is_pushing = false;
    var total_products = 0;
    var pushed_products = 0;

    $('#wws-push-form').on('submit', function(e) {
        e.preventDefault();

        if (is_pushing) {
            return;
        }
        
        is_pushing = true;
        $('#wws-progress-container').show();
        $('#wws-start-push-btn').prop('disabled', true);
        
        // Initial AJAX call to start the process
        sendAjaxRequest();
    });

    function sendAjaxRequest() {
        $.ajax({
            url: wws_push_vars.ajax_url, // Using the localized variable
            type: 'POST',
            data: {
                action: 'wws_start_shopify_push',
                _wpnonce: wws_push_vars.nonce,
                // You can add other data from your form here, e.g., limit and push_type
                limit: $('input[name="limit"]').val(),
                push_type: $('input[name="push_type"]:checked').val(),
            },
            success: function(response) {
                if (response.success) {
                    var data = response.data;
                    total_products = data.total;
                    pushed_products = data.pushed;
                    
                    updateProgressBar();
                    
                    if (data.status === 'complete') {
                        $('#wws-status-text').text("Process complete. Successfully pushed " + data.pushed + " products.");
                        is_pushing = false;
                        $('#wws-start-push-btn').prop('disabled', false);
                    } else {
                        // Continue to the next batch
                        sendAjaxRequest();
                    }
                    
                    if (data.errors && data.errors.length > 0) {
                        data.errors.forEach(function(error) {
                            $('#wws-error-log').append('<li>' + error.message + ' (Product ID: ' + error.product_id + ')</li>');
                        });
                    }
                } else {
                    $('#wws-status-text').text("Error: " + (response.data.message || "An unknown error occurred."));
                    is_pushing = false;
                    $('#wws-start-push-btn').prop('disabled', false);
                }
            },
            error: function() {
                $('#wws-status-text').text("An unexpected error occurred.");
                is_pushing = false;
                $('#wws-start-push-btn').prop('disabled', false);
            }
        });
    }

    function updateProgressBar() {
        if (total_products === 0) {
            $('#wws-progress-bar').css('width', '100%').text('100%');
            return;
        }

        var percent = Math.round((pushed_products / total_products) * 100);
        $('#wws-progress-bar').css('width', percent + '%').text(pushed_products + ' / ' + total_products + ' (' + percent + '%)');
    }
});