<?php
/**
 * WWS Shopify API Class
 *
 * Handles communication with Shopify API for pushing WooCommerce products and customers.
 */
class WWS_Shopify_API {

    /**
     * The transient key for progress tracking.
     */
    const PROGRESS_TRANSIENT_KEY = 'wws_shopify_push_progress';

    /**
     * Push WooCommerce products to Shopify.
     * This function is now the AJAX entry point for the process.
     */
    public static function push_products_to_shopify() {
        if (!class_exists('WC_Product')) {
            wp_send_json_error(['message' => 'WooCommerce is not active.']);
        }

        // Get and update progress from transient
        $progress = get_transient(self::PROGRESS_TRANSIENT_KEY);
        if ($progress === false) {
            $total_products = self::get_total_publishable_products();
            $progress = [
                'total' => $total_products,
                'pushed' => 0,
                'status' => 'pushing',
                'errors' => [],
            ];
            set_transient(self::PROGRESS_TRANSIENT_KEY, $progress, DAY_IN_SECONDS);
        }

        $args = [
            'limit' => 5, // Process in batches
            'status' => 'publish',
            'offset' => $progress['pushed'],
        ];
        $products = wc_get_products($args);

        if (empty($products)) {
            $progress['status'] = 'complete';
            set_transient(self::PROGRESS_TRANSIENT_KEY, $progress, DAY_IN_SECONDS);
            wp_send_json_success($progress);
        }

        foreach ($products as $product) {
            $payload = self::prepare_shopify_product_payload($product);

            if (empty($payload)) {
                $progress['pushed']++;
                continue;
            }
            
            // Check if product with this title already exists in Shopify to avoid duplicates
            // This is a crucial step for a reliable sync.
            // You may want to add a custom meta field for Shopify ID after a successful push.
            $existing_product = self::find_product_by_title_or_sku($payload['product']['title']);

            if (!$existing_product) {
                $response = self::send_shopify_api_request(
                    $store,
                    $token,
                    'products.json',
                    $payload,
                    'POST'
                );

                if (is_wp_error($response)) {
                    $progress['errors'][] = [
                        'product_id' => $product->get_id(),
                        'message' => $response->get_error_message(),
                    ];
                    error_log('Shopify Product Push Error: ' . $response->get_error_message());
                } else {
                    $total_pushed++;
                    // Optional: Store the Shopify product ID back in WooCommerce for future updates.
                    // update_post_meta($product->get_id(), '_shopify_id', $response['product']['id']);
                }
            } else {
                // Product already exists, you can choose to update it here if needed.
                // For this example, we will just skip it.
                $progress['errors'][] = [
                    'product_id' => $product->get_id(),
                    'message' => 'Product already exists in Shopify, skipping.',
                ];
            }

            $progress['pushed']++;
        }

        set_transient(self::PROGRESS_TRANSIENT_KEY, $progress, DAY_IN_SECONDS);
        wp_send_json_success($progress);
    }
    
    // Add this new private helper function
    private static function get_total_publishable_products() {
        $args = [
            'status' => 'publish',
            'limit' => -1,
            'return' => 'ids',
        ];
        return count(wc_get_products($args));
    }
    
    /**
     * Prepare product data payload for Shopify API.
     * Includes all images and variant-specific images in a single payload.
     */
    private static function prepare_shopify_product_payload($product) {
        $vendor = get_option('wws_shopify_default_vendor', '') ?: '';
        $product_type = WWS_Utils::get_product_type($product);
        $tags = WWS_Utils::get_product_tags($product);

        $payload = [
            'product' => [
                'title'         => $product->get_name(),
                'body_html'     => $product->get_description(),
                'vendor'        => $vendor,
                'product_type'  => $product_type,
                'published'     => $product->get_status() === 'publish',
                'tags'          => $tags,
                'variants'      => [],
                'images'        => [],
            ]
        ];

        // Collect all images from main product and variants first
        $all_images = [];

        // Add main product image
        $main_img_id = $product->get_image_id();
        if ($main_img_id) {
            $src = wp_get_attachment_url($main_img_id);
            $alt = get_post_meta($main_img_id, '_wp_attachment_image_alt', true);
            if ($src) {
                $all_images[$main_img_id] = ['src' => $src, 'alt' => $alt];
            }
        }

        // Add gallery images
        foreach ($product->get_gallery_image_ids() as $img_id) {
            $src = wp_get_attachment_url($img_id);
            $alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
            if ($src && !isset($all_images[$img_id])) {
                $all_images[$img_id] = ['src' => $src, 'alt' => $alt];
            }
        }

        // Add variant-specific images
        if ($product->is_type('variable')) {
            foreach ($product->get_children() as $var_id) {
                $variant = wc_get_product($var_id);
                $img_id = $variant->get_image_id();
                if ($img_id && !isset($all_images[$img_id])) {
                    $src = wp_get_attachment_url($img_id);
                    $alt = get_post_meta($img_id, '_wp_attachment_image_alt', true);
                    if ($src) {
                        $all_images[$img_id] = ['src' => $src, 'alt' => $alt];
                    }
                }
            }
        }
        
        $payload['product']['images'] = array_values($all_images);

        // Prepare variants payload, linking images
        if ($product->is_type('simple')) {
            $payload['product']['variants'][] = self::prepare_simple_product_variant($product, $payload['product']['images']);
        } elseif ($product->is_type('variable')) {
            self::add_variable_product_data($product, $payload);
        }

        return $payload;
    }

    /**
     * Add simple product data to Shopify payload.
     * Note: This now links the variant to the main image.
     */
    private static function prepare_simple_product_variant($product, $images) {
        $variant = [
            'sku'                  => $product->get_sku(),
            'grams'                => WWS_Utils::weight_to_grams($product->get_weight()),
            'inventory_management' => 'shopify',
            'inventory_quantity'   => $product->managing_stock() ? $product->get_stock_quantity() : null,
            'inventory_policy'     => $product->backorders_allowed() ? 'continue' : 'deny',
            'fulfillment_service'  => 'manual',
            'price'                => $product->get_price(),
            'compare_at_price'     => $product->get_regular_price() ?: null,
            'requires_shipping'    => !$product->get_virtual(),
            'taxable'              => $product->is_taxable(),
            'barcode'              => $product->get_meta('_barcode') ?: $product->get_sku(),
        ];

        // Link variant to its primary image
        $main_img_id = $product->get_image_id();
        if ($main_img_id) {
            foreach ($images as $key => $img) {
                if (strpos($img['src'], basename(wp_get_attachment_url($main_img_id))) !== false) {
                    $variant['image_id'] = $key + 1; // Shopify image_id is 1-indexed based on position
                    break;
                }
            }
        }
        
        return $variant;
    }

    /**
     * Add variable product data to Shopify payload.
     */
    private static function add_variable_product_data($product, &$payload) {
        $options = [];
        $image_map = [];

        // Build a map of WooCommerce image IDs to their position in the final images array.
        foreach ($payload['product']['images'] as $index => $img) {
            $wc_image_id = attachment_url_to_postid($img['src']);
            if ($wc_image_id) {
                $image_map[$wc_image_id] = $index;
            }
        }

        foreach ($product->get_children() as $var_id) {
            $variant = wc_get_product($var_id);
            if (!$variant) continue;

            $attrs = $variant->get_variation_attributes();
            $variant_options = [];
            $i = 0;

            foreach ($attrs as $attribute_slug => $value_slug) {
                if ($i >= 3) break;
                $attribute_name = wc_attribute_label(str_replace('attribute_', '', $attribute_slug));
                $value = preg_replace('/^\d+-/', '', $value_slug);
                $variant_options[] = $value;

                if (!isset($options[$i])) {
                    $options[$i]['name'] = $attribute_name;
                    $options[$i]['values'] = [];
                }
                if (!in_array($value, $options[$i]['values'])) {
                    $options[$i]['values'][] = $value;
                }
                $i++;
            }

            $variant_payload = [
                'option1'              => $variant_options[0] ?? null,
                'option2'              => $variant_options[1] ?? null,
                'option3'              => $variant_options[2] ?? null,
                'sku'                  => $variant->get_sku(),
                'grams'                => WWS_Utils::weight_to_grams($variant->get_weight()),
                'inventory_management' => 'shopify',
                'inventory_quantity'   => $variant->managing_stock() ? $variant->get_stock_quantity() : null,
                'inventory_policy'     => $variant->backorders_allowed() ? 'continue' : 'deny',
                'fulfillment_service'  => 'manual',
                'price'                => $variant->get_price(),
                'compare_at_price'     => $variant->get_regular_price() ?: null,
                'requires_shipping'    => !$variant->get_virtual(),
                'taxable'              => $variant->is_taxable(),
                'barcode'              => $variant->get_meta('_barcode') ?: $variant->get_sku(),
            ];

            // Assign the correct image_id to the variant
            $img_id = $variant->get_image_id();
            if ($img_id && isset($image_map[$img_id])) {
                $variant_payload['image_id'] = $payload['product']['images'][$image_map[$img_id]]['id'] ?? null;
            }

            $payload['product']['variants'][] = $variant_payload;
        }

        $payload['product']['options'] = array_values($options);
    }

    /**
     * Send a request to Shopify Admin API.
     */
    private static function send_shopify_api_request($store, $token, $endpoint, $data = [], $method = 'GET') {
        $url = "https://{$store}/admin/api/2023-01/{$endpoint}";
        // The rest of your existing function
    }
}