<?php
class WWS_Utils {
    public static function get_product_type($product) {
        $terms = wp_get_post_terms($product->get_id(), 'product_cat', ['fields' => 'names']);
        return !empty($terms) ? $terms[0] : '';
    }

    public static function get_product_tags($product) {
        $terms = wp_get_post_terms($product->get_id(), 'product_tag', ['fields' => 'names']);
        return !empty($terms) ? implode(', ', $terms) : '';
    }

    public static function weight_to_grams($weight) {
        if (!$weight) return '';
        $unit = get_option('woocommerce_weight_unit', 'kg');
        $w = floatval($weight);
        
        switch (strtolower($unit)) {
            case 'kg': return round($w * 1000);
            case 'g': return round($w);
            case 'lb': return round($w * 453.59237);
            case 'oz': return round($w * 28.3495231);
            default: return round($w * 1000);
        }
    }

    public static function unique_key($email, $phone, $by='email') {
        if ($by === 'phone') return 'phone_' . preg_replace('/\D/', '', $phone);
        return 'email_' . strtolower(trim($email));
    }

    public static function get_province_code($country, $province) {
        return '';
    }

    public static function country_code_from_country($country) {
        return '';
    }
    
    public static function get_attribute_display_name($attribute_name) {
    $clean_name = str_replace('pa_', '', $attribute_name);
    return ucfirst(str_replace('-', ' ', $clean_name));
}

public static function format_option_name($name, $index) {
    if (empty($name) || $name === 'pa_' || strpos($name, 'option') === 0) {
        return "Option $index";
    }
    return self::get_attribute_display_name($name);
}
}


?>