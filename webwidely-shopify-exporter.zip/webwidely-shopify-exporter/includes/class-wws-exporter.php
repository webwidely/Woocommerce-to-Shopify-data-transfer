<?php
/**
 * Class WWS_Exporter
 *
 * Handles exporting WooCommerce products to a Shopify-compatible CSV format.
 */
class WWS_Exporter {

	/**
	 * Exports WooCommerce products to a Shopify-compatible CSV file.
	 *
	 * @param bool $include_variations Whether to include product variations.
	 * @param int  $limit The number of products to export (batch size). 0 for all products.
	 * @param int  $offset The starting product number for the export.
	 * 
	 * @return void
	 */
	public static function export_products_csv( $include_variations = true, $limit = 0, $offset = 0 ) {
		// REMOVED: Environment validation check

		// Validate and sanitize input parameters
		$include_variations = (bool) $include_variations;
		$limit              = absint( $limit );
		$offset             = absint( $offset );

		$headers = array(
			'Handle',
			'Title',
			'Body (HTML)',
			'Vendor',
			'Type',
			'Tags',
			'Published',
			'Option1 Name',
			'Option1 Value',
			'Option2 Name',
			'Option2 Value',
			'Option3 Name',
			'Option3 Value',
			'Variant SKU',
			'Variant Grams',
			'Variant Inventory Tracker',
			'Variant Inventory Qty',
			'Variant Inventory Policy',
			'Variant Fulfillment Service',
			'Variant Price',
			'Variant Compare-at Price',
			'Variant Requires Shipping',
			'Variant Taxable',
			'Variant Barcode',
			'Image Src',
			'Image Alt Text',
			'Variant Image',
			'Additional Information (product.metafields.custom.additional_information)',
		);

		$filename = 'shopify-products-' . gmdate( 'Ymd-His' ) . '.csv';
		
		// Send headers for file download
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . sanitize_file_name( $filename ) . '"' );
		header( 'Pragma: no-cache' );
		header( 'Expires: 0' );

		$output = fopen( 'php://output', 'w' );
		
		// Add BOM for UTF-8 encoding
		fwrite( $output, "\xEF\xBB\xBF" );
		
		// Write headers
		fputcsv( $output, $headers );

		// Get products with proper error handling
		$args = array(
			'limit'   => ( $limit > 0 ) ? $limit : -1,
			'offset'  => $offset,
			'status'  => array( 'publish', 'draft', 'private' ),
			'orderby' => 'ID',
			'order'   => 'ASC',
			'return'  => 'ids', // More efficient to get IDs first
		);

		$product_ids = wc_get_products( $args );
		
		if ( is_wp_error( $product_ids ) || empty( $product_ids ) ) {
			fclose( $output );
			wp_die( esc_html__( 'No products found to export.', 'wws-exporter' ) );
		}

		// Process products in batches to prevent memory issues
		foreach ( $product_ids as $product_id ) {
			$product = wc_get_product( $product_id );
			
			if ( ! $product ) {
				continue;
			}

			if ( $product->is_type( 'variable' ) && $include_variations ) {
				self::write_variable_product_rows( $output, $product );
			} else {
				self::write_simple_product_row( $output, $product );
			}
			
			// Clean up memory for this product
			wc_delete_product_transients( $product_id );
		}

		fclose( $output );
		exit;
	}

	/**
	 * Writes CSV rows for a simple product.
	 *
	 * @param resource $output File pointer to the CSV output.
	 * @param WC_Product $product Product object.
	 */
	private static function write_simple_product_row( $output, $product ) {
		$handle    = sanitize_title( $product->get_name() );
		$title     = $product->get_name();
		$body      = $product->get_description();
		$vendor    = get_option( 'wws_shopify_default_vendor', '' );
		$type      = implode( ', ', wp_get_object_terms( $product->get_id(), 'product_type', array( 'fields' => 'names' ) ) );
		$tags      = self::get_product_tags_and_categories( $product );
		$published = $product->get_status() === 'publish' ? 'TRUE' : 'FALSE';

		$additional_info_json = self::get_additional_information_json( $product );

		$variant_sku      = $product->get_sku();
		$grams            = self::weight_to_grams( $product->get_weight() );
		$inventory_qty    = $product->managing_stock() ? $product->get_stock_quantity() : '';
		$inventory_policy = $product->backorders_allowed() ? 'continue' : 'deny';

		$price             = $product->get_price();
		$compare_at        = ( $product->get_regular_price() && $product->get_regular_price() > $price ) ? $product->get_regular_price() : '';
		$requires_shipping = $product->get_virtual() ? 'FALSE' : 'TRUE';
		$taxable           = $product->is_taxable() ? 'TRUE' : 'FALSE';
		$barcode           = $product->get_meta( '_barcode', true ) ?: $variant_sku;

		// Get main image
		$image_src = '';
		$image_alt = '';
		$image_id  = $product->get_image_id();
		if ( $image_id ) {
			$image_src = wp_get_attachment_url( $image_id );
			$image_alt = get_post_meta( $image_id, '_wp_attachment_image_alt', true ) ?: $title;
		}

		$row = array(
			$handle,
			$title,
			$body,
			$vendor,
			$type,
			$tags,
			$published,
			'', '', '', '', '', '', // Option fields
			$variant_sku,
			$grams,
			'', // Inventory Tracker
			$inventory_qty,
			$inventory_policy,
			'manual',
			$price,
			$compare_at,
			$requires_shipping,
			$taxable,
			$barcode,
			$image_src,
			$image_alt,
			'', // Variant Image
			$additional_info_json,
		);

		fputcsv( $output, $row );

		// Add gallery images as additional rows
		$gallery_image_ids = $product->get_gallery_image_ids();
		if ( ! empty( $gallery_image_ids ) ) {
			foreach ( $gallery_image_ids as $img_id ) {
				$img_src = wp_get_attachment_url( $img_id );
				if ( ! $img_src ) {
					continue;
				}
				
				$img_alt = get_post_meta( $img_id, '_wp_attachment_image_alt', true ) ?: $title;
				
				$image_row = array(
					$handle, '', '', '', '', '', '', // Basic info
					'', '', '', '', '', '', // Options
					'', '', '', '', '', '', // Variant details
					'', '', '', '', '', // Pricing and shipping
					$img_src, $img_alt, '', // Image columns
					'', // Additional info
				);
				
				fputcsv( $output, $image_row );
			}
		}
	}

	/**
 * Writes CSV rows for a variable product and its variations.
 * FIXED: Now correctly maps variation values to product attribute names.
 *
 * @param resource $output File pointer to the CSV output.
 * @param WC_Product_Variable $product Variable product object.
 */
private static function write_variable_product_rows( $output, $product ) {
	$handle    = sanitize_title( $product->get_name() );
	$title     = $product->get_name();
	$body      = $product->get_description();
	$vendor    = get_option( 'wws_shopify_default_vendor', '' );
	$type      = $product->get_type();
	$tags      = self::get_product_tags_and_categories( $product );
	$published = $product->get_status() === 'publish' ? 'TRUE' : 'FALSE';

	$additional_info_json = self::get_additional_information_json( $product );

	// Get the product's ATTRIBUTES (e.g., Color, Size) - these become "Option1 Name", "Option2 Name"
	$product_attributes = $product->get_attributes();
	$option_names       = array( '', '', '' ); // Initialize with empty strings

	// Populate the option names from the product's attributes
	$i = 0;
	foreach ( $product_attributes as $attribute_key => $attribute ) {
		if ( $i >= 3 ) { // Shopify only supports 3 options
			break;
		}
		// Get the clean attribute name (e.g., 'pa_color' becomes 'Color')
		$option_names[ $i ] = wc_attribute_label( $attribute_key );
		$i++;
	}

	$variation_ids = $product->get_children();
	
	if ( empty( $variation_ids ) ) {
		// If no variations, fall back to simple product
		self::write_simple_product_row( $output, $product );
		return;
	}

	$first_row_written = false;
	$seen_combinations = array();

	// Get main product image for the first variant row
	$main_image_src = '';
	$main_image_alt = '';
	$main_image_id  = $product->get_image_id();
	if ( $main_image_id ) {
		$main_image_src = wp_get_attachment_url( $main_image_id );
		$main_image_alt = get_post_meta( $main_image_id, '_wp_attachment_image_alt', true ) ?: $title;
	}

	foreach ( $variation_ids as $variation_id ) {
		$variation = wc_get_product( $variation_id );
		if ( ! $variation || ! $variation->exists() ) {
			continue;
		}

		// Get the variation's ATTRIBUTES
		$variation_attributes = $variation->get_variation_attributes();
		$option_values        = array( '', '', '' ); // Initialize with empty strings
		$current_combination  = array();

		// Map each variation attribute to its corresponding product attribute
		$j = 0;
		foreach ( $product_attributes as $product_attr_key => $product_attr ) {
			if ( $j >= 3 ) break;
			
			$attribute_value = '';
			$variation_attr_key = 'attribute_' . $product_attr_key;
			
			// Check if this variation has this attribute
			if ( isset( $variation_attributes[ $variation_attr_key ] ) ) {
				$attribute_slug = $variation_attributes[ $variation_attr_key ];
				
				if ( ! empty( $attribute_slug ) && $attribute_slug !== 'null' ) {
					// For taxonomy attributes, get the term name
					if ( taxonomy_exists( $product_attr_key ) ) {
						$term = get_term_by( 'slug', $attribute_slug, $product_attr_key );
						if ( $term && ! is_wp_error( $term ) ) {
							$attribute_value = $term->name;
						} else {
							$attribute_value = ucfirst( str_replace( '-', ' ', $attribute_slug ) );
						}
					} else {
						// For custom attributes, use the value as stored
						$attribute_value = $attribute_slug;
					}
				}
			}
			
			// If we still have no value, use a default
			if ( empty( $attribute_value ) ) {
				$attribute_value = 'Default';
			}
			
			$option_values[ $j ] = $attribute_value;
			$current_combination[] = $attribute_value;
			$j++;
		}

		// Check for duplicate combinations
		$combination_key = implode( '||', $current_combination );
		if ( in_array( $combination_key, $seen_combinations, true ) ) {
			continue;
		}
		$seen_combinations[] = $combination_key;

		// Get variation details
		$variant_sku      = $variation->get_sku();
		$grams            = self::weight_to_grams( $variation->get_weight() );
		$inventory_qty    = $variation->managing_stock() ? $variation->get_stock_quantity() : '';
		$inventory_policy = $variation->backorders_allowed() ? 'continue' : 'deny';
		$price            = $variation->get_price();
		$compare_at       = ( $variation->get_regular_price() && $variation->get_regular_price() > $price ) ? $variation->get_regular_price() : '';
		$requires_shipping = $variation->get_virtual() ? 'FALSE' : 'TRUE';
		$taxable           = $variation->is_taxable() ? 'TRUE' : 'FALSE';
		$barcode           = $variation->get_meta( '_barcode', true ) ?: $variant_sku;

		// Get variant-specific image
		$variant_image    = '';
		$variant_image_id = $variation->get_image_id();
		if ( $variant_image_id ) {
			$variant_image = wp_get_attachment_url( $variant_image_id );
		}

		// Use main product image for the first row, variant image for others
		$image_src = $first_row_written ? '' : $main_image_src;
		$image_alt = $first_row_written ? '' : $main_image_alt;

		// Build the row for this variation
		$row = array(
			$handle,
			$first_row_written ? '' : $title, // Only show title on first row
			$first_row_written ? '' : $body,
			$first_row_written ? '' : $vendor,
			$first_row_written ? '' : $type,
			$first_row_written ? '' : $tags,
			$first_row_written ? '' : $published,
			// Map the correct option names to their values
			$option_names[0], $option_values[0],
			$option_names[1], $option_values[1],
			$option_names[2], $option_values[2],
			// Variant details
			$variant_sku,
			$grams,
			'', // Inventory Tracker
			$inventory_qty,
			$inventory_policy,
			'manual',
			$price,
			$compare_at,
			$requires_shipping,
			$taxable,
			$barcode,
			$image_src,
			$image_alt,
			$variant_image,
			$first_row_written ? '' : $additional_info_json,
		);

		fputcsv( $output, $row );
		$first_row_written = true;
	}

	// If no variations were written (all were duplicates), write the main product as simple
	if ( ! $first_row_written ) {
		self::write_simple_product_row( $output, $product );
	}
}
	private static function get_product_tags_and_categories( $product ) {
		$tags = array();
		
		// Get product tags
		$product_tags = wp_get_object_terms( $product->get_id(), 'product_tag', array( 'fields' => 'names' ) );
		if ( ! empty( $product_tags ) && ! is_wp_error( $product_tags ) ) {
			$tags = array_merge( $tags, $product_tags );
		}
		
		// Get product categories
		$product_categories = wp_get_object_terms( $product->get_id(), 'product_cat', array( 'fields' => 'names' ) );
		if ( ! empty( $product_categories ) && ! is_wp_error( $product_categories ) ) {
			$tags = array_merge( $tags, $product_categories );
		}
		
		// Sanitize and limit tag length for Shopify compatibility
		$tags = array_map( 'sanitize_text_field', $tags );
		$tags = array_slice( $tags, 0, 250 ); // Shopify has a limit
		
		return implode( ', ', $tags );
	}

	/**
	 * Converts a weight value to grams based on WooCommerce settings.
	 *
	 * @param float|string|null $weight The weight value from WooCommerce.
	 * @return int Converted weight in grams.
	 */
	private static function weight_to_grams( $weight ) {
		if ( empty( $weight ) ) {
			return 0;
		}
		
		$weight = (float) $weight;
		$unit   = get_option( 'woocommerce_weight_unit' );
		
		switch ( $unit ) {
			case 'kg':
				return (int) round( $weight * 1000 );
			case 'lbs':
				return (int) round( $weight * 453.592 );
			case 'oz':
				return (int) round( $weight * 28.3495 );
			case 'g':
			default:
				return (int) round( $weight );
		}
	}

	/**
	 * Retrieves all product attributes and formats them into a JSON string.
	 *
	 * @param WC_Product $product The product object.
	 * @return string The JSON string or empty string on error.
	 */
	private static function get_additional_information_json( $product ) {
		$attributes = $product->get_attributes();
		if ( empty( $attributes ) ) {
			return '';
		}

		$info_array = array();
		foreach ( $attributes as $attribute ) {
			$name = wc_attribute_label( $attribute->get_name() );
			
			if ( $attribute->is_taxonomy() ) {
				$values = wc_get_product_terms( $product->get_id(), $attribute->get_name(), array( 'fields' => 'names' ) );
			} else {
				$values = $attribute->get_options();
				$values = array_map( 'esc_html', $values );
			}
			
			$value_str = implode( ', ', $values );
			
			$info_array[] = array(
				'name'  => $name,
				'value' => $value_str,
			);
		}

		$json = wp_json_encode( $info_array, JSON_UNESCAPED_UNICODE | JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS );
		
		return ( $json !== false ) ? $json : '';
	}
}