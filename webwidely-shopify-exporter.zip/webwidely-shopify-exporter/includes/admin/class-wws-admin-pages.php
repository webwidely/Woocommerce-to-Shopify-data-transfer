<?php
class WWS_Admin_Pages {

    /**
     * Renders the dashboard page for CSV export.
     */
    public static function page_dashboard() {
        if (!current_user_can('manage_options')) return;
        ?>
        <div class="wrap">
            <h1>WWS → Shopify Exporter</h1>
            <p>Export WooCommerce products and customers to Shopify-compatible CSV files.</p>

            <h2>Export Products (Shopify CSV)</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('wws_export_products_nonce'); ?>
                <input type="hidden" name="action" value="wws_export_products">
                <p>
                    <label><input type="checkbox" name="include_variations" checked> Include variations as Shopify variants</label>
                </p>
                <p>
                    <label>Limit products (0 = all): <input type="number" name="limit" value="0"></label>
                </p>
                <p><button class="button button-primary">Export Products CSV</button></p>
            </form>

            <hr>
            <h2>Export Customers (Shopify CSV)</h2>
            <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                <?php wp_nonce_field('wws_export_customers_nonce'); ?>
                <input type="hidden" name="action" value="wws_export_customers">
                <p>
                    <label><input type="checkbox" name="include_guests" checked> Include guest customers (derived from orders)</label>
                </p>
                <p>
                    <label>Only unique by (choose one):
                        <select name="unique_by">
                            <option value="email">Email</option>
                            <option value="phone">Phone</option>
                        </select>
                    </label>
                </p>
                <p><button class="button">Export Customers CSV</button></p>
            </form>

            <hr>
            <h2>Notes & Tips</h2>
            <ul>
                <li>Shopify requires specific CSV headers — this plugin uses Shopify's official product & customer column order for compatibility.</li>
                <li>Image URLs must be publicly accessible to import into Shopify (Shopify will try to download the images from the provided URLs).</li>
                <li>Large stores: exporting a very large product or order set can take time and may hit PHP limits. Consider using smaller batches if you have thousands of items.</li>
            </ul>
        </div>
        <?php
    }

    /**
     * Renders the settings page.
     */
    public static function page_settings() {
        if (!current_user_can('manage_options')) return;
        $store = esc_attr(get_option('wws_shopify_store', ''));
        $token = esc_attr(get_option('wws_shopify_token', ''));
        $vendor = esc_attr(get_option('wws_shopify_default_vendor', ''));
        ?>
        <div class="wrap">
            <h1>WWS → Shopify Settings</h1>
            <form method="post" action="options.php">
                <?php settings_fields('wws_shopify_settings'); do_settings_sections('wws_shopify_settings'); ?>
                <table class="form-table">
                    <tr>
                        <th>Shopify store (example.myshopify.com)</th>
                        <td><input type="text" name="wws_shopify_store" value="<?php echo $store; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Admin API access token</th>
                        <td><input type="text" name="wws_shopify_token" value="<?php echo $token; ?>" class="regular-text"></td>
                    </tr>
                    <tr>
                        <th>Default Vendor</th>
                        <td><input type="text" name="wws_shopify_default_vendor" value="<?php echo $vendor; ?>" class="regular-text"></td>
                    </tr>
                </table>
                <?php submit_button(); ?>
            </form>
        </div>
        <?php
    }

    /**
     * Renders the push data page with the AJAX-based progress bar.
     */
    public static function page_push() {
        if (!current_user_can('manage_options')) {
            return;
        }

        // Enqueue the JavaScript file for the push process
        // Note: You must save the following JavaScript code in a file named 'wws-push.js'
        // and place it in a 'js' folder inside your plugin's main directory.
        wp_enqueue_script(
            'wws-push-script',
            plugin_dir_url(__FILE__) . 'js/wws-push.js',
            ['jquery'],
            '1.0',
            true
        );

        // Pass PHP variables to the JavaScript file using wp_localize_script()
        wp_localize_script(
            'wws-push-script',
            'wws_push_vars',
            [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce'    => wp_create_nonce('wws_push_to_shopify_nonce'),
            ]
        );
        ?>
        <div class="wrap">
            <h1>Push Data to Shopify</h1>
            <p>From here you can push (create) products or customers directly to the connected Shopify store. Use carefully — this will create resources in the target store.</p>
            
            <form id="wws-push-form" method="post">
                <input type="hidden" name="action" value="wws_start_shopify_push">
                
                <p>
                    <label>
                        <input type="radio" name="push_type" value="products" checked> Push products
                    </label><br>
                    <label>
                        <input type="radio" name="push_type" value="customers"> Push customers
                    </label>
                </p>
                
                <p>
                    <label>Limit (0 = all): <input type="number" name="limit" value="10"></label>
                </p>
                
                <p>
                    <button id="wws-start-push-btn" class="button button-primary">Start Push</button>
                </p>
            </form>

            <div id="wws-progress-container" style="display:none; padding: 20px; background: #fff; border: 1px solid #ccc; border-radius: 5px; margin-top: 20px;">
                <h2>Push Status:</h2>
                <div id="wws-progress-bar" style="width: 0%; height: 25px; background-color: #4fbb83; border-radius: 5px; text-align: center; color: #121212; font-weight: bold; line-height: 25px; transition: width 0.3s ease-in-out;">0%</div>
                <p id="wws-status-text" style="font-weight: bold; margin-top: 10px;">Starting...</p>
                <ul id="wws-error-log" style="color: #c0392b; list-style-type: disc; margin-left: 20px;"></ul>
            </div>
            
        </div>
        <?php
    }
}
?>