<?php
class WWS_Admin_Handlers {
    public static function init() {
        add_action('admin_post_wws_export_products', [__CLASS__, 'handle_export_products']);
        add_action('admin_post_wws_export_customers', [__CLASS__, 'handle_export_customers']);
        add_action('admin_post_wws_push_to_shopify', [__CLASS__, 'handle_push_to_shopify']);
    }

    public static function handle_export_products() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('wws_export_products_nonce');

        $include_variations = isset($_POST['include_variations']);
        $limit = intval($_POST['limit'] ?? 0);

        WWS_Exporter::export_products_csv($include_variations, $limit);
    }

    public static function handle_export_customers() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('wws_export_customers_nonce');

        $include_guests = isset($_POST['include_guests']);
        $unique_by = sanitize_text_field($_POST['unique_by'] ?? 'email');

        WWS_Exporter::export_customers_csv($include_guests, $unique_by);
    }

    public static function handle_push_to_shopify() {
        if (!current_user_can('manage_options')) wp_die('Not allowed');
        check_admin_referer('wws_push_to_shopify_nonce');

        $push_type = sanitize_text_field($_POST['push_type']);
        $limit = intval($_POST['limit'] ?? 0);

        $store = get_option('wws_shopify_store');
        $token = get_option('wws_shopify_token');

        if (empty($store) || empty($token)) {
            wp_redirect(add_query_arg('wws_msg', 'missing_creds', admin_url('admin.php?page=wws-shopify-exporter-push')));
            exit;
        }

        if ($push_type === 'products') {
            WWS_Shopify_API::push_products_to_shopify($store, $token, $limit);
        } else {
            WWS_Shopify_API::push_customers_to_shopify($store, $token, $limit);
        }
    }
}

// Initialize handlers
WWS_Admin_Handlers::init();
?>