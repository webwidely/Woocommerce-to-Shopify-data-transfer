<?php
class WWS_Shopify_Exporter {
    private static $instance = null;
    private $option_group = 'wws_shopify_settings';

    public static function instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_action('admin_menu', [$this, 'admin_menu']);
    }

    public function admin_menu() {
        $cap = 'manage_options';
        add_menu_page('WWS Shopify Exporter', 'WWS → Shopify', $cap, 'wws-shopify-exporter', ['WWS_Admin_Pages', 'page_dashboard'], 'dashicons-upload');
        add_submenu_page('wws-shopify-exporter', 'Export', 'Export', $cap, 'wws-shopify-exporter', ['WWS_Admin_Pages', 'page_dashboard']);
        add_submenu_page('wws-shopify-exporter', 'Settings', 'Settings', $cap, 'wws-shopify-exporter-settings', ['WWS_Admin_Pages', 'page_settings']);
        add_submenu_page('wws-shopify-exporter', 'Push to Shopify', 'Push to Shopify', $cap, 'wws-shopify-exporter-push', ['WWS_Admin_Pages', 'page_push']);
    }
}
?>